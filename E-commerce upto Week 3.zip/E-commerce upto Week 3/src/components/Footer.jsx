import React from 'react'
import '../App.css'

function Footer() {
  return (
    <div className='footer common'>
        <a href="#" className="fa fa-facebook"></a>
        <a href="#" className="fa fa-twitter"></a>
        <a href="#" className="fa fa-google"></a>
        <a href="#" className="fa fa-linkedin"></a>
        <a href="#" className="fa fa-youtube"></a>
    </div>
  )
}

export default Footer
